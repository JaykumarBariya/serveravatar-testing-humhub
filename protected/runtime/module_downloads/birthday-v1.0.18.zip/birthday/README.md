[![Test Status](https://github.com/humhub-contrib/birthday/workflows/PHP%20Codeception%20Tests/badge.svg)](https://github.com/humhub-contrib/birthday/actions)

# Birthday Widget

Show your appreciation to your colleagues and brighten their day with warm wishes.

## Feature Overview

- Adds a widget to your dashboard with upcoming birthdays
- Period for which the upcoming birthdays should be displayed is configurable
- Users can hide their year of birth / age