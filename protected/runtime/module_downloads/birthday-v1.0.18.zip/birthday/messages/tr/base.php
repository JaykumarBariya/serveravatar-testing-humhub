<?php
return array (
  '<strong>Birthdays</strong> within the next {days} days' => 'Önümüzdeki {days} gün içinde doğum günleri',
  'Back to modules' => 'Modüllere dön',
  'Birthday Module Configuration' => 'Doğum Günü Modülü Yapılandırması',
  'In {days} days' => '{days} gün içinde',
  'Save' => 'Kaydet',
  'The group id of the group that should be exluded.' => 'Hariç tutulacak grubun grup kimliği.',
  'The number of days future birthdays will be shown within.' => 'Gelecekteki doğum günleri gün içinde gösterilecektir.',
  'Tomorrow' => 'Yarın',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'Yaklaşan doğum günlerinde gösterilen gün sayısını yapılandırabilirsiniz.',
  'becomes {years} years old.' => '{years} yaşında oldu.',
  'today' => 'bugün',
);
