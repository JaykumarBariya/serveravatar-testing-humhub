<?php
return [
  '<strong>Birthdays</strong> within the next {days} days' => '<strong>Aniversariantes</strong> nos próximos {days} dias',
  'Back to modules' => 'Voltar aos módulos',
  'Birthday Module Configuration' => 'Configuração do Módulo de Aniversário',
  'In {days} days' => 'Em {days} dias',
  'Save' => 'Salvar',
  'The group id of the group that should be exluded.' => 'O ID do grupo que deve ser excluído.',
  'The number of days future birthdays will be shown within.' => 'O número de dias em que os aniversários futuros serão exibidos.',
  'Tomorrow' => 'Amanhã',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'Você pode configurar o número de dias dentro dos quais os próximos aniversários serão exibidos.',
  'becomes {years} years old.' => 'completa {years} anos',
  'today' => 'hoje',
];
