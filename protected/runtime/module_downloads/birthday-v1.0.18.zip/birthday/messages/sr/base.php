<?php
return array (
  '<strong>Birthdays</strong> within the next {days} days' => '<strong>Rođendani</strong> u nadolazećih {days} dana',
  'Back to modules' => 'Povratak na module',
  'Birthday Module Configuration' => 'Konfiguracija rođendanskog modula',
  'In {days} days' => 'U {days} dana',
  'Save' => 'Sačuvaj',
  'The group id of the group that should be exluded.' => 'ID grupe od grupe koja će biti izostavljena.',
  'The number of days future birthdays will be shown within.' => 'Broj dana u kojima će se budući rođendani prikazivati.',
  'Tomorrow' => 'Sutra',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'Možete konfigurirati broj dana u predstojećim rođendanima.',
  'becomes {years} years old.' => 'ima {years} godina.',
  'today' => 'danas',
);
