<?php
return array (
  '<strong>Birthdays</strong> within the next {days} days' => '<strong>Geburtstage</strong> in den nächsten {days} Tagen',
  'Back to modules' => 'Zurück zu den Modulen',
  'Birthday Module Configuration' => 'Konfiguration Geburtstagsmodul',
  'In {days} days' => 'In {days} Tagen',
  'Save' => 'Speichern',
  'The group id of the group that should be exluded.' => 'Die Gruppen-ID der Gruppe, die ausgeschlossen werden soll.',
  'The number of days future birthdays will be shown within.' => 'Die Anzahl der Tage, an denen die zukünftigen Geburtstage angezeigt werden.',
  'Tomorrow' => 'Morgen',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'Du kannst die Anzahl an Tagen einstellen, an denen zukünftige Geburstage vorab angezeigt werden.',
  'becomes {years} years old.' => 'wird {years} Jahre alt.',
  'today' => 'heute',
);
