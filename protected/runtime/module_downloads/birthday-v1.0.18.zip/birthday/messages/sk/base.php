<?php
return array (
  '<strong>Birthdays</strong> within the next {days} days' => '<strong>Narodeniny</strong> v priebehu nasledujúcich {days} dní',
  'Back to modules' => 'Späť k modulom',
  'Birthday Module Configuration' => 'Konfigurácia modulu Narodeniny',
  'In {days} days' => 'O {days} dní',
  'Save' => 'Uložiť',
  'The group id of the group that should be exluded.' => 'ID skupiny, ktorá by mala byť vylúčená.',
  'The number of days future birthdays will be shown within.' => 'Počet dní, počas ktorých sa budú zobrazovať budúce narodeniny.',
  'Tomorrow' => 'Zajtra',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'Môžete nakonfigurovať počet dní, počas ktorých sa budú zobrazovať nadchádzajúce narodeniny.',
  'becomes {years} years old.' => 'bude mať {years} rokov.',
  'today' => 'dnes',
);
