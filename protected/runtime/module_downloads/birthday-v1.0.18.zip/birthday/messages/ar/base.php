<?php
return array (
  '<strong>Birthdays</strong> within the next {days} days' => '<strong>أيام الميلاد</strong> خلال الأيام الـ {days} القادمة',
  'Back to modules' => 'عودة للموديولات',
  'Birthday Module Configuration' => 'إعدادات موديول يوم الميلاد',
  'In {days} days' => 'في {days} أيام',
  'Save' => 'حفظ',
  'The group id of the group that should be exluded.' => 'معرف المجموعة للمجموعة التي يجب استبعادها.',
  'The number of days future birthdays will be shown within.' => 'عدد الأيام التي سيتم عرض أيام الميلاد المستقبلية فيها.',
  'Tomorrow' => 'غداً',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'يمكنك تحديد عدد الأيام التي يظهر في إشعار بقرب يوم الميلاد',
  'becomes {years} years old.' => 'يصبح عمره {years} سنة.',
  'today' => 'اليوم',
);
