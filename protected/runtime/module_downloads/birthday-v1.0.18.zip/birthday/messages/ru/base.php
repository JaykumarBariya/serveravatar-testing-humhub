<?php
return array (
  '<strong>Birthdays</strong> within the next {days} days' => '<strong>Дни рождения</strong> в течение следующих {days} дней',
  'Back to modules' => 'Назад к модулям',
  'Birthday Module Configuration' => 'Настройки модуля <strong>Дни рождения</strong>',
  'In {days} days' => 'В {days} днях',
  'Save' => 'Сохранить',
  'The group id of the group that should be exluded.' => 'Идентификатор группы, которая должна быть исключена.',
  'The number of days future birthdays will be shown within.' => 'Внутри будет показано количество дней, в течение которых будут отмечаться будущие дни рождения.',
  'Tomorrow' => 'Завтра',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'Вы можете настроить количество предстоящих дней рождения для отображения в блоке.',
  'becomes {years} years old.' => 'становится на {years} лет старше.',
  'today' => 'сегодня',
);
