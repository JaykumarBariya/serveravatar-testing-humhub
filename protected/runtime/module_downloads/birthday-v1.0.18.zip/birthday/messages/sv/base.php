<?php
return [
  '<strong>Birthdays</strong> within the next {days} days' => '<strong>Födelsedagar</strong> kommande {days} dagar',
  'Back to modules' => 'Tillbaka till moduler',
  'Birthday Module Configuration' => 'Födelsedagsmodul inställningar',
  'In {days} days' => 'Om {days} dagar',
  'Save' => 'Spara',
  'The group id of the group that should be exluded.' => 'Grupp-id för gruppen som skall exkluderas.',
  'The number of days future birthdays will be shown within.' => 'Antal dagar som visas under kommande födelsedagar.',
  'Tomorrow' => 'imorgon',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'Du kan ställa in hur många dagar som visas under kommande födelsedagar.',
  'becomes {years} years old.' => 'fyller {years} år.',
  'today' => 'idag',
];
