<?php
return array (
  '<strong>Birthdays</strong> within the next {days} days' => '<strong>Cumpleaños</strong> dentro de los siguientes {days} días',
  'Back to modules' => 'Regresar a los Módulos',
  'Birthday Module Configuration' => 'Configuración del módulo Cumpleaños',
  'In {days} days' => 'En {days} días',
  'Save' => 'Guardar',
  'The group id of the group that should be exluded.' => 'La group id del grupo que debe excluirse.',
  'The number of days future birthdays will be shown within.' => 'El número de días que se mostrarán los cumpleaños futuros.',
  'Tomorrow' => 'Mañana',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'Debes configurar el número de días para mostrar los cumpleaños.',
  'becomes {years} years old.' => 'cumplirá {years} años de edad.',
  'today' => 'hoy',
);
