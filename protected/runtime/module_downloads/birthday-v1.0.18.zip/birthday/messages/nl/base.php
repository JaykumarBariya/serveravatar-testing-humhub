<?php
return array (
  '<strong>Birthdays</strong> within the next {days} days' => '<strong>Verjaardagen</strong> in de komende {days} dagen',
  'Back to modules' => 'Terug naar modules',
  'Birthday Module Configuration' => 'Verjaardagen module configuratie',
  'In {days} days' => 'Over {days} dagen',
  'Save' => 'Opslaan',
  'The group id of the group that should be exluded.' => 'De ID van de groep die moet worden uitgesloten.',
  'The number of days future birthdays will be shown within.' => 'Het aantal dagen waarin toekomstige verjaardagen worden getoond.',
  'Tomorrow' => 'Morgen',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'U kunt het aantal dagen waarin toekomstige verjaardagen getoond worden instellen.',
  'becomes {years} years old.' => 'wordt {years} jaar oud.',
  'today' => 'vandaag',
);
