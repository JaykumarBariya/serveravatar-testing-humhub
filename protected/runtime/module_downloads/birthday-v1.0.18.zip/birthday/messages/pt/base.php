<?php
return array (
  '<strong>Birthdays</strong> within the next {days} days' => '<strong>Aniversários</strong> nos próximos {days} dias',
  'Back to modules' => 'Voltar para os módulos',
  'Birthday Module Configuration' => 'Configuração do Módulo Aniversários',
  'In {days} days' => 'Em {days} dias',
  'Save' => 'Guardar',
  'The group id of the group that should be exluded.' => 'A ID de grupo do grupo que deve ser excluído.',
  'The number of days future birthdays will be shown within.' => 'O intervalo do número de dias para futuros aniversários.',
  'Tomorrow' => 'Amanhã',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'Podes configurar como é mostrado o número de dias de entre os próximos aniversários.',
  'becomes {years} years old.' => 'terá {years} anos de idade.',
  'today' => 'hoje',
);
