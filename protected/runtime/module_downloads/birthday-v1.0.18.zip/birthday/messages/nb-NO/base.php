<?php
return array (
  '<strong>Birthdays</strong> within the next {days} days' => '<strong>Bursdager</strong> de kommende {days} dagene',
  'Back to modules' => 'Tilbake til moduler',
  'Birthday Module Configuration' => 'Konfigurér bursdag-modulen',
  'In {days} days' => 'Om {days} dager',
  'Save' => 'Lagre',
  'The group id of the group that should be exluded.' => 'ID for de gruppene som skal være ekskludert.',
  'The number of days future birthdays will be shown within.' => 'Antall dager fremtidige fødselsdager vil bli synlige.',
  'Tomorrow' => 'I morgen',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'Du kan konfigerere antall dager å vise bursdager innenfor.',
  'becomes {years} years old.' => 'blir {years} år gammel.',
  'today' => 'i dag',
);
