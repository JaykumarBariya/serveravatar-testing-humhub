<?php
return array (
  '<strong>Birthdays</strong> within the next {days} days' => '',
  'Back to modules' => '返回模組',
  'Birthday Module Configuration' => '生日模組設定',
  'In {days} days' => '',
  'Save' => '儲存',
  'The group id of the group that should be exluded.' => '',
  'The number of days future birthdays will be shown within.' => '',
  'Tomorrow' => '明天',
  'You may configure the number of days within the upcoming birthdays are shown.' => '您可設定多少天前會通知即將到來的生日',
  'becomes {years} years old.' => '',
  'today' => '今天',
);
