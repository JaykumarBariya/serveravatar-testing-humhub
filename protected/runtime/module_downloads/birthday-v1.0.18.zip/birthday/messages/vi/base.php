<?php
return array (
  '<strong>Birthdays</strong> within the next {days} days' => '<strong>Sinh nhật</strong> Trong {days} hôm tới',
  'Back to modules' => 'Quay trở lại modules',
  'Birthday Module Configuration' => 'Cấu hình Module Birthday',
  'In {days} days' => 'Trong {days} ngày',
  'Save' => 'Lưu',
  'The group id of the group that should be exluded.' => 'Group ID của nhóm mà nên được loại bỏ',
  'The number of days future birthdays will be shown within.' => 'Số ngày trước ngày sinh nhật mà thông báo chúc mừng sẽ bắt đầu được hiển thị',
  'Tomorrow' => 'Ngày mai',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'Bạn có thể cấu hình khoảng ngày của các sinh nhật sắp tới.',
  'becomes {years} years old.' => 'Đã {years} tuổi.',
  'today' => 'hôm nay',
);
