<?php
return array (
  '<strong>Birthdays</strong> within the next {days} days' => '<strong>วันเกิด</strong> ภายใน {days} วันถัดไป',
  'Back to modules' => 'กลับไปที่โมดูล',
  'Birthday Module Configuration' => 'การกำหนดค่าโมดูลวันเกิด',
  'In {days} days' => 'ภายใน {days} วัน',
  'Save' => 'บันทึก',
  'The group id of the group that should be exluded.' => 'รหัสกลุ่มของกลุ่มที่ควรยกเว้น',
  'The number of days future birthdays will be shown within.' => 'จำนวนวันที่เกิดในอนาคตจะแสดงภายใน',
  'Tomorrow' => 'พรุ่งนี้',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'คุณสามารถกำหนดจำนวนวันภายในวันเกิดที่จะมาถึงได้',
  'becomes {years} years old.' => 'มีอายุ {years} ปี',
  'today' => 'วันนี้',
);
