<?php
return array (
  '<strong>Birthdays</strong> within the next {days} days' => '<strong>Narozeniny</strong> v následujících {days} dnech',
  'Back to modules' => 'Zpět na přehled modulů',
  'Birthday Module Configuration' => 'Nastavení modulu Narozeniny',
  'In {days} days' => 'Ve {days} dnech',
  'Save' => 'Uložit',
  'The group id of the group that should be exluded.' => 'ID skupiny skupiny, která má být vyloučena.',
  'The number of days future birthdays will be shown within.' => 'Počet dní, během kterých se zobrazí budoucí narozeniny.',
  'Tomorrow' => 'Zítra',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'Můžete nastavit počet dnů před narozeninami, kdy na ně bude upozorněno.',
  'becomes {years} years old.' => 'dosáhne věku {years}.',
  'today' => 'dnes',
);
