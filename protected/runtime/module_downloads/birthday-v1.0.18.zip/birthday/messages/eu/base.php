<?php
return array (
  '<strong>Birthdays</strong> within the next {days} days' => '',
  'Back to modules' => 'Itzuli moduluetara',
  'Birthday Module Configuration' => '',
  'In {days} days' => '',
  'Save' => 'Gorde',
  'The group id of the group that should be exluded.' => '',
  'The number of days future birthdays will be shown within.' => '',
  'Tomorrow' => '',
  'You may configure the number of days within the upcoming birthdays are shown.' => '',
  'becomes {years} years old.' => '',
  'today' => '',
);
