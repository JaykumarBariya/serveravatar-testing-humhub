<?php
return array (
  '<strong>Birthdays</strong> within the next {days} days' => '다음 {days}일 이내에 <strong>생일</strong>인 사용자가 있습니다.',
  'Back to modules' => '모듈로 돌아가기',
  'Birthday Module Configuration' => '생일 모듈 구성',
  'In {days} days' => '{days}일 후',
  'Save' => '저장',
  'The group id of the group that should be exluded.' => '제외해야 하는 그룹의 그룹 ID입니다.',
  'The number of days future birthdays will be shown within.' => '향후 생일 일수가 표시됩니다.',
  'Tomorrow' => '내일',
  'You may configure the number of days within the upcoming birthdays are shown.' => '예정된 생일이 표시되는 일 수를 구성할 수 있습니다.',
  'becomes {years} years old.' => '{years} 세가 됩니다.',
  'today' => '오늘',
);
