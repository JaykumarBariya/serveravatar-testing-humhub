<?php

namespace humhub\modules\tasks\activities;

use humhub\modules\activity\components\BaseActivity;

class Finished extends BaseActivity
{
    public $moduleId = 'tasks';
    public $viewName = "finished";

}
