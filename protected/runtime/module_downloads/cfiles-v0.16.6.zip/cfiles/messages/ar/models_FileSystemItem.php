<?php

return [
    'Downloads' => '',
    'Hide in Stream' => '',
    'Is Public' => '',
    'Note: Changes of the folders visibility, will be inherited by all contained files and folders.' => '',
];
