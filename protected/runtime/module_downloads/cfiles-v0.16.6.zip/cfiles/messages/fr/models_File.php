<?php
return array (
  'Folder ID' => 'ID dossier',
);
