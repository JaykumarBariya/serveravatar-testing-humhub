<?php
return array (
  'Downloads' => 'Téléchargements',
  'Hide in Stream' => 'Masquer dans le fil d’actualités',
  'Is Public' => 'est public',
  'Note: Changes of the folders visibility, will be inherited by all contained files and folders.' => 'Note : les modifications de la visibilité des dossiers sont également appliquées à tous les fichiers et dossiers qu\'ils contiennent.',
);
