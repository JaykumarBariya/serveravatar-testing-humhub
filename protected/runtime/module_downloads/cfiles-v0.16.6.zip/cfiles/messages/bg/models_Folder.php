<?php
return array (
  'Description' => 'Описание',
  'Parent Folder ID' => 'Идентификационен номер на основната папка',
  'Title' => 'Заглавие',
);
