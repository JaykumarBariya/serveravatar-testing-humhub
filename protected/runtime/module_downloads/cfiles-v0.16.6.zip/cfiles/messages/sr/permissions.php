<?php
return array (
  'Add files' => 'Dodaj fajlove',
  'Allows the user to modify or delete any files.' => 'Korisniku omogućuje izmenu ili brisanje svih fajlova.',
  'Allows the user to upload new files and create folders' => 'Korisniku omogućuje prenos novih fajlova i stvaranje foldera',
  'Manage files' => 'Upravljaj fajlovima',
);
