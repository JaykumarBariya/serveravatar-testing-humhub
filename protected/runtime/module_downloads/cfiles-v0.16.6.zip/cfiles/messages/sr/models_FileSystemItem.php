<?php
return array (
  'Downloads' => 'Preuzimanja',
  'Hide in Stream' => '',
  'Is Public' => 'Javno',
  'Note: Changes of the folders visibility, will be inherited by all contained files and folders.' => 'Napomena: Promene vidljivosti fascikala nasljeđuju sve sadržane datoteke i mape.',
);
