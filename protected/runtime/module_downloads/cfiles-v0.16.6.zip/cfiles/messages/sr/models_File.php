<?php
return array (
  'Folder ID' => 'ID fascikle',
);
