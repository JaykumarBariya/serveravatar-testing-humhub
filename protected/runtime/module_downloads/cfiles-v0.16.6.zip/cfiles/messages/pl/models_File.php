<?php
return array (
  'Folder ID' => 'ID Foldera',
);
