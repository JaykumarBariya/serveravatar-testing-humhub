<?php
return array (
  'Description' => 'Descrição',
  'Parent Folder ID' => 'ID Pasta Mãe',
  'Title' => 'Título',
);
