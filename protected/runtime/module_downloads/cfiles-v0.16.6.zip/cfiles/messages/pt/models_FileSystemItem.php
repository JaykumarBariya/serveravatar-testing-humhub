<?php

return [
    'Downloads' => 'Descarregamentos',
    'Is Public' => 'É Público',
    'Note: Changes of the folders visibility, will be inherited by all contained files and folders.' => 'Nota: mudanças na visibilidade das pastas serão herdadas por todos os ficheiros e pastas inclusos',
    'Hide in Stream' => '',
];
