<?php
return array (
  'Folder ID' => 'Mappa azonosító',
);
