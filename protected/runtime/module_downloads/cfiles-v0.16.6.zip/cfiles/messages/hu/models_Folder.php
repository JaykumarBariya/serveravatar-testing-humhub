<?php
return array (
  'Description' => 'Leírás',
  'Parent Folder ID' => 'Szülő mappa azonosítója',
  'Title' => 'Név',
);
