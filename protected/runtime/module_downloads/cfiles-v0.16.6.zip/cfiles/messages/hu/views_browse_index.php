<?php
return array (
  'Could not save file %title%. ' => 'Nem sikerült a(z) %title% fájlt menteni.',
);
