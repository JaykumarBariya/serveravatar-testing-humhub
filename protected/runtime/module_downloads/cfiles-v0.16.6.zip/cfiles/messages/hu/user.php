<?php
return array (
  'Are you really sure to delete this version?' => 'Biztos, hogy törli ezt a verziót?',
  'The version "{versionDate}" could not be deleted!' => '"{versionDate}" verziót nem sikerült törölni!',
  'The version "{versionDate}" has been deleted.' => '"{versionDate}” verzió törölve.',
);
