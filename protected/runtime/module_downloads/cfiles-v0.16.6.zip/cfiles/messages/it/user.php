<?php
return array (
  'Are you really sure to delete this version?' => 'Sei davero sicuro di cancellare questa versione?',
  'The version "{versionDate}" could not be deleted!' => 'La versione "{versionDate}" non  può essere cancellata!',
  'The version "{versionDate}" has been deleted.' => 'La versione "{versionDate}" è stata cancellata.',
);
