<?php
return array (
  'Could not save file %title%. ' => 'Non posso salvare il file %title%.',
);
