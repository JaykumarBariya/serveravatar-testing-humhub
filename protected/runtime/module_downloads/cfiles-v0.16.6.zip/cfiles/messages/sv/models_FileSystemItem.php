<?php

return [
    'Downloads' => 'Nedladdningar',
    'Is Public' => 'Är publik',
    'Note: Changes of the folders visibility, will be inherited by all contained files and folders.' => 'Notera: Ändringar av mapparnas synlighet ärvs av alla filer &amp; mappar.',
    'Hide in Stream' => '',
];
