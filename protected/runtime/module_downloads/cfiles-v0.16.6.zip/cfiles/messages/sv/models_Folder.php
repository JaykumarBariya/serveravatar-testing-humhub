<?php
return array (
  'Description' => 'Beskrivning',
  'Parent Folder ID' => 'ID för överordnad mapp',
  'Title' => 'Rubrik',
);
