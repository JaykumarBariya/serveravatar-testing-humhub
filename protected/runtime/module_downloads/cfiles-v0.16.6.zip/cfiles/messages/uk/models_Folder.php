<?php
return array (
  'Description' => 'Опис',
  'Parent Folder ID' => '',
  'Title' => 'Заголовок',
);
