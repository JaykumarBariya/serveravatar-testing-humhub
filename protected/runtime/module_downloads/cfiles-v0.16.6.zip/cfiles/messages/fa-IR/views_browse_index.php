<?php
return array (
  'Could not save file %title%. ' => 'ذخيره نشد %title% فايل',
);
