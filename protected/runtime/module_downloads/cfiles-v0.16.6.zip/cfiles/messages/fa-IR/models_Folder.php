<?php
return array (
  'Description' => 'توضیحات',
  'Parent Folder ID' => '',
  'Title' => 'عنوان',
);
