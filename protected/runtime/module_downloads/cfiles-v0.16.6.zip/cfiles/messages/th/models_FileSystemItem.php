<?php

return [
    'Downloads' => 'ดาวน์โหลด',
    'Is Public' => 'เป็นสาธารณะ',
    'Note: Changes of the folders visibility, will be inherited by all contained files and folders.' => 'หมายเหตุ: การเปลี่ยนแปลงการเปิดเผยโฟลเดอร์ ไฟล์และโฟลเดอร์ที่มีอยู่ทั้งหมดจะสืบทอดมา',
    'Hide in Stream' => '',
];
