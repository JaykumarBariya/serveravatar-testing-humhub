<?php
return array (
  'Could not save file %title%. ' => 'ไม่สามารถบันทึกไฟล์ %title%',
);
