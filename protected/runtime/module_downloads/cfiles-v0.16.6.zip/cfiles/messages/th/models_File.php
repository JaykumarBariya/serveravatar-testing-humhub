<?php
return array (
  'Folder ID' => 'รหัสโฟลเดอร์',
);
