<?php
return array (
  'Are you really sure to delete this version?' => 'このバージョンを削除してもよろしいですか？',
  'The version "{versionDate}" could not be deleted!' => 'バージョン "{versionDate}" を削除できませんでした！',
  'The version "{versionDate}" has been deleted.' => 'バージョン "{versionDate}" は削除されました。',
);
