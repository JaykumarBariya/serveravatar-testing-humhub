<?php
return array (
  'Downloads' => 'ダウンロード',
  'Hide in Stream' => 'ストリームに隠す',
  'Is Public' => '公開中',
  'Note: Changes of the folders visibility, will be inherited by all contained files and folders.' => '注：フォルダーの可視性の変更は含まれているすべてのファイルとフォルダーに継承されます。',
);
