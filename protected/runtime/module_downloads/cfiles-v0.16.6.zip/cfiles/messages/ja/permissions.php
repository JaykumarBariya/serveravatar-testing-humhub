<?php
return array (
  'Add files' => '追加ファイル',
  'Allows the user to modify or delete any files.' => '任意のファイルを変更または削除できるようにします。',
  'Allows the user to upload new files and create folders' => '新しいファイルをアップロードしてフォルダを作成できるようにします',
  'Manage files' => 'ファイルの管理',
);
