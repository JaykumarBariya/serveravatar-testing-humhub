<?php
return array (
  'Description' => '説明',
  'Parent Folder ID' => '親フォルダー ID',
  'Title' => 'タイトル',
);
