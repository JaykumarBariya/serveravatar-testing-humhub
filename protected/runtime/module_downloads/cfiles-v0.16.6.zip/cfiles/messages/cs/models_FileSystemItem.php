<?php
return array (
  'Downloads' => '',
  'Hide in Stream' => '',
  'Is Public' => 'Je veřejný',
  'Note: Changes of the folders visibility, will be inherited by all contained files and folders.' => '',
);
