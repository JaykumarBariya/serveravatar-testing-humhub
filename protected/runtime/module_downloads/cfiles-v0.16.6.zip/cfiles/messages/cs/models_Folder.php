<?php
return array (
  'Description' => 'Popis',
  'Parent Folder ID' => '',
  'Title' => 'Název',
);
