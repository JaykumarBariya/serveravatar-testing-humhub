<?php
return array (
  'Folder ID' => 'Kansion ID',
);
