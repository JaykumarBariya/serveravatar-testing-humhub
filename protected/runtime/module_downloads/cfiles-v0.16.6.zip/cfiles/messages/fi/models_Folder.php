<?php
return array (
  'Description' => 'Kuvaus',
  'Parent Folder ID' => 'Kansion ID',
  'Title' => 'Otsikko',
);
