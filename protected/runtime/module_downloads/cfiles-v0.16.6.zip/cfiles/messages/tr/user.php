<?php
return array (
  'Are you really sure to delete this version?' => 'Bu versiyonu silmek istediğinizden emin misiniz?',
  'The version "{versionDate}" could not be deleted!' => '',
  'The version "{versionDate}" has been deleted.' => '',
);
