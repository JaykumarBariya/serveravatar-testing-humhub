<?php
return array (
  'Description' => 'Descrição',
  'Parent Folder ID' => 'ID da Pasta Pai',
  'Title' => 'Título',
);
