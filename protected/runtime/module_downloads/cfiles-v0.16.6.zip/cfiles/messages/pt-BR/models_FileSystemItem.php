<?php

return [
    'Downloads' => 'Transferências',
    'Is Public' => 'É Público',
    'Note: Changes of the folders visibility, will be inherited by all contained files and folders.' => 'Nota: Mudanças na visibilidade das pastas serão herdadas por todos os arquivos e pastas contidas nelas.',
    'Hide in Stream' => '',
];
