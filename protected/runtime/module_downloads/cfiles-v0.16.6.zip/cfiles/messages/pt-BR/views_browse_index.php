<?php
return array (
  'Could not save file %title%. ' => 'Não é possível salvar o arquivo %title%. ',
);
