<?php
return array (
  'Description' => 'Mô tả',
  'Parent Folder ID' => 'ID thư mục mẹ',
  'Title' => 'Tiêu đề',
);
