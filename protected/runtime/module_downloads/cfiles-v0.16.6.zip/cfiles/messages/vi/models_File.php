<?php
return array (
  'Folder ID' => 'ID thư mục',
);
