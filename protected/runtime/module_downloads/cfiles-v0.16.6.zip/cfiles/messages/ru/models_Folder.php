<?php
return array (
  'Description' => 'Описание',
  'Parent Folder ID' => '',
  'Title' => 'Заголовок',
);
