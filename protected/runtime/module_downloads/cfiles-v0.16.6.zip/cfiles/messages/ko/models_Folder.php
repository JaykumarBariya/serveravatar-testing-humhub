<?php
return array (
  'Description' => '설명',
  'Parent Folder ID' => '',
  'Title' => '제목',
);
