<?php
return array (
  'Add answer...' => 'เพิ่มคำตอบ...',
  'Anonymous Votes?' => 'โหวตแบบไม่ระบุชื่อ?',
  'Description' => 'คำอธิบาย',
  'Display answers in random order?' => 'แสดงคำตอบแบบสุ่ม?',
  'Edit answer (empty answers will be removed)...' => 'แก้ไขคำตอบ (คำตอบที่ว่างเปล่าจะถูกลบออก)...',
  'Edit your poll question...' => 'แก้ไขคำถามแบบสำรวจของคุณ...',
  'Hide results until poll is closed?' => 'ซ่อนผลลัพธ์จนกว่าจะปิดโพล?',
  'Question' => 'คำถาม',
);
