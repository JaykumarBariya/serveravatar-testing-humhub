<?php
return array (
  'Again? ;Weary;' => 'อีกแล้วเหรอ? ;เหน็ดเหนื่อย;',
  'Club A Steakhouse' => 'คลับ เอ สเต็กเฮาส์',
  'Location of the next meeting' => 'สถานที่ประชุมครั้งต่อไป',
  'Pisillo Italian Panini' => 'Pisillo อิตาลี Panini',
  'Right now, we are in the planning stages for our next meetup and we would like to know from you, where you would like to go?' => 'ตอนนี้เราอยู่ในขั้นตอนการวางแผนสำหรับการมีตติ้งครั้งต่อไป และเราอยากทราบจากคุณว่าคุณต้องการไปที่ไหน',
  'To Daniel' => 'ถึงแดเนียล',
  'Why don\'t we go to Bemelmans Bar?' => 'ทำไมไม่ลองไปที่ Bemelmans Bar ล่ะ?',
);
