<?php

return [
    'Allows the user to create polls' => 'อนุญาตให้ผู้ใช้สร้างโพล',
    'Allows to start polls.' => 'อนุญาตให้เริ่มการเลือกตั้ง',
    'Answers' => 'คำตอบ',
    'At least one answer is required' => 'จำเป็นต้องมีอย่างน้อยหนึ่งคำตอบ',
    'Cancel' => 'ยกเลิก',
    'Create poll' => 'สร้างโพล',
    'Polls' => 'โพล',
    'Save' => 'บันทึก',
    '{n,plural,=1{# {htmlTagBegin}vote{htmlTagEnd}}other{# {htmlTagBegin}votes{htmlTagEnd}}}' => '',
];
