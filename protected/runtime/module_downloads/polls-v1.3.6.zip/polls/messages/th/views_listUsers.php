<?php
return array (
  'User who vote this' => 'ผู้ใช้ที่โหวตสิ่งนี้',
);
