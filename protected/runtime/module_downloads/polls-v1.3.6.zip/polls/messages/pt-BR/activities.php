<?php
return array (
  'Polls' => 'Enquete',
  'Whenever someone participates in a poll.' => 'Sempre que alguém participa de uma votação.',
);
