<?php

return [
    'Allows the user to create polls' => 'Permite ao usuário criar enquetes',
    'Allows to start polls.' => 'Permite iniciar enquetes.',
    'Answers' => 'Respostas',
    'At least one answer is required' => 'É necessária pelo menos uma resposta',
    'Cancel' => 'Cancelar',
    'Create poll' => 'Criar enquete',
    'Polls' => 'Enquete',
    'Save' => 'Salvar',
    '{n,plural,=1{# {htmlTagBegin}vote{htmlTagEnd}}other{# {htmlTagBegin}votes{htmlTagEnd}}}' => '{n,plural,=1{# {htmlTagBegin}voto{htmlTagEnd}}other{# {htmlTagBegin}votos{htmlTagEnd}}}',
];
