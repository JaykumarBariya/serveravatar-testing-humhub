<?php
return array (
  'Access denied!' => 'Zugriff verweigert!',
  'Anonymous poll!' => 'Anonyme Umfrage!',
  'Could not load poll!' => 'Konnte Umfrage nicht laden!',
  'Invalid answer!' => 'Ungültige Antwort!',
  'Users voted for: <strong>{answer}</strong>' => 'Benutzer stimmten für: <strong>{answer}</strong>',
  'Voting for multiple answers is disabled!' => 'Mehrfachantworten sind nicht zugelassen!',
  'You have insufficient permissions to perform that operation!' => 'Du hast keine ausreichenden Berechtigungen, um diesen Vorgang auszuführen!',
);
