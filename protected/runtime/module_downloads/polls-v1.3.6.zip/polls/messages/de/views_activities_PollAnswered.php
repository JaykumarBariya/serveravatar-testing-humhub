<?php
return array (
  '{userName} answered the {question}.' => '{userName} hat an der Umfrage "{question}" teilgenommen.',
);
