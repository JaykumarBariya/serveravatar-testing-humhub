<?php
return array (
  'Allows the user to create polls' => 'Erlaubt es dem Benutzer Umfragen zu erstellen',
  'Allows to start polls.' => 'Ermöglicht Umfragen zu starten.',
  'Answers' => 'Antworten',
  'At least one answer is required' => 'Mindestens eine Antwort erforderlich.',
  'Cancel' => 'Abbrechen',
  'Create poll' => 'Umfrage erstellen',
  'Polls' => 'Umfragen',
  'Save' => 'Speichern',
  '{n,plural,=1{# {htmlTagBegin}vote{htmlTagEnd}}other{# {htmlTagBegin}votes{htmlTagEnd}}}' => '{n,plural,=1{# {htmlTagBegin}Stimme{htmlTagEnd}}other{# {htmlTagBegin}Stimmen{htmlTagEnd}}}',
);
