<?php

return [
    'Answers' => 'Atsakymai',
    'Cancel' => 'Atšaukti',
    'Polls' => 'Apklausos',
    'Save' => 'Išsaugoti',
    'Allows the user to create polls' => '',
    'Allows to start polls.' => '',
    'At least one answer is required' => '',
    'Create poll' => '',
    '{n,plural,=1{# {htmlTagBegin}vote{htmlTagEnd}}other{# {htmlTagBegin}votes{htmlTagEnd}}}' => '',
];
