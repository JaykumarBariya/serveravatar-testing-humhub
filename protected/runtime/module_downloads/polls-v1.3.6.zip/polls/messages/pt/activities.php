<?php
return array (
  'Polls' => 'Votações',
  'Whenever someone participates in a poll.' => 'Quando alguém participa numa votação.',
);
