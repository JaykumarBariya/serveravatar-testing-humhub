<?php
return array (
  'Again? ;Weary;' => 'Outra vez? ;cansado;',
  'Club A Steakhouse' => 'Churrasqueira Club A',
  'Location of the next meeting' => 'Local da próxima reunião',
  'Pisillo Italian Panini' => 'Pisillo Panini italiano',
  'Right now, we are in the planning stages for our next meetup and we would like to know from you, where you would like to go?' => 'Neste momento, estamos na fase de planeamento do nosso próximo encontro e gostávamos de saber de ti, onde gostarias de ir?',
  'To Daniel' => 'Para o Daniel',
  'Why don\'t we go to Bemelmans Bar?' => 'Porque é que não vamos ao Bar Bemelmans?',
);
