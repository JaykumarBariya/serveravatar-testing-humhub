<?php
return array (
  '{userName} created a new poll and assigned you.' => '{userName} skapade en undersökning som tilldelades dig.',
);
