<?php
return array (
  'User who vote this' => 'Användare som röstade så här',
);
