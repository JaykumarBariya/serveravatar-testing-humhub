<?php
return array (
  'Answers' => 'Svar',
  'Description' => 'Beskrivning',
  'Multiple answers per user' => 'Flera svar per användare',
  'Please specify at least {min} answers!' => 'Ange minst {min} svar!',
  'Poll' => 'Enkät',
  'Question' => 'Fråga',
);
