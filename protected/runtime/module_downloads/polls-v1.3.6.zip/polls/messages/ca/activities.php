<?php
return array (
  'Polls' => 'Enquestes',
  'Whenever someone participates in a poll.' => 'Sempre que algú participi en una enquesta.',
);
