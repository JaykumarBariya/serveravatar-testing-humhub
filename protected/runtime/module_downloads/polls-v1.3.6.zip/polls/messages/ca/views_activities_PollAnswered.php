<?php
return array (
  '{userName} answered the {question}.' => '{userName} ha respost {question}.',
);
