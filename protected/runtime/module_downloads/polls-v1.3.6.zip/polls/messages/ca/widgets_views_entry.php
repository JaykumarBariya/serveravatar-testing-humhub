<?php
return array (
  '<strong>Note:</strong> The result is hidden until the poll is closed by a moderator.' => '<strong>Nota:</strong> El resultat s\'amaga fins que un moderador tanca l\'enquesta.',
  'Anonymous' => 'Anònim',
  'Closed' => 'Tancada',
  'Complete Poll' => 'Completar enquesta',
  'Reopen Poll' => 'Reobrir enquesta',
  'Reset my vote' => 'Restableix el meu vot',
  'Vote' => 'Vot',
  'and {count} more vote for this.' => 'i {count} més han votat això.',
  'votes' => 'vots',
);
