<?php
return array (
  'Add answer...' => 'Afegir resposta...',
  'Anonymous Votes?' => 'Vots anònims?',
  'Description' => 'Descripció',
  'Display answers in random order?' => 'Mostrar les respostes en ordre aleatori?',
  'Edit answer (empty answers will be removed)...' => 'Editar resposta (respostes buides seran eliminades)...',
  'Edit your poll question...' => 'Editar la pregunta de l\'enquesta',
  'Hide results until poll is closed?' => 'Amagar resultats fins que es tanqui l\'enquesta?',
  'Question' => 'Pregunta',
);
