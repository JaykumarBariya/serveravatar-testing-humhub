<?php

return [
    'Allows the user to create polls' => 'Permet a l\'usuari crear enquestes',
    'Allows to start polls.' => 'Permet iniciar enquestes.',
    'Answers' => 'Respostes',
    'At least one answer is required' => 'Almenys una resposta és necessària',
    'Cancel' => 'Cancel·la',
    'Create poll' => 'Crear enquesta',
    'Polls' => 'Enquestes',
    'Save' => 'Desa',
    '{n,plural,=1{# {htmlTagBegin}vote{htmlTagEnd}}other{# {htmlTagBegin}votes{htmlTagEnd}}}' => '',
];
