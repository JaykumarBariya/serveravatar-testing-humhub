<?php
return array (
  '{userName} answered the {question}.' => '{userName} megválaszolta ezt: {question}.',
);
