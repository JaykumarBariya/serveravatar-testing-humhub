<?php
return array (
  'Polls' => 'Ψηφοφορίες',
  'Whenever someone participates in a poll.' => 'Όταν κάποιος συμμετέχει σε ψηφοφορία.',
);
