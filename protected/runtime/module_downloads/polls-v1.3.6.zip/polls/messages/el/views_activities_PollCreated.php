<?php
return array (
  '{userName} created a new {question}.' => 'Ο/Η {userName} δημιούργησε μια νέα {question}.',
);
