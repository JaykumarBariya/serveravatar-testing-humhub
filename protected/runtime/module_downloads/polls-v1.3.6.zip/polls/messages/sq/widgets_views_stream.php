<?php

return [
    '<b>There are no polls yet!</b>' => '',
    '<b>There are no polls yet!</b><br>Be the first and create one...' => '',
    'Asked by me' => '',
    'No answered yet' => '',
    'Only private polls' => '',
    'Only public polls' => '',
];
