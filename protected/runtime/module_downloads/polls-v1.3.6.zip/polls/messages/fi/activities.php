<?php
return array (
  'Polls' => 'Kyselyt',
  'Whenever someone participates in a poll.' => '',
);
