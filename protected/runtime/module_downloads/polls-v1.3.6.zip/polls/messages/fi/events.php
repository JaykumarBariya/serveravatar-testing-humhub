<?php

return [
    'Again? ;Weary;' => 'Uudelleen? ;Weary;',
    'Club A Steakhouse' => 'Club A Steakhouse',
    'Pisillo Italian Panini' => 'Pisillo Italian Panini',
    'Right now, we are in the planning stages for our next meetup and we would like to know from you, where you would like to go?' => 'Juuri nyt olemme suunnitteluvaiheessa seuraavaan tapaamisemme ja haluaisimme tietää teiltä, mistä haluaisit mennä?',
    'To Daniel' => 'Danielille',
    'Why don\'t we go to Bemelmans Bar?' => 'Miksi emme mene Bemelmans Bariin?',
    'Location of the next meeting' => '',
];
