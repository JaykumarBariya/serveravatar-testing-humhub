<?php
return array (
  'Answers' => 'Respuestas',
  'Description' => 'Descripción',
  'Multiple answers per user' => 'Multiples respuestas por usuario',
  'Please specify at least {min} answers!' => '¡Por favor, especifica al menos {min} respuestas!',
  'Poll' => 'Pregunta',
  'Question' => 'Pregunta',
);
