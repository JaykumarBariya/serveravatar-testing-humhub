<?php
return array (
  '<strong>Note:</strong> The result is hidden until the poll is closed by a moderator.' => '<strong>Nota:</strong> el resultado se oculta hasta que un moderador cierra la encuesta.',
  'Anonymous' => 'Anónimos',
  'Closed' => 'Cerrado',
  'Complete Poll' => 'Terminar la encuesta',
  'Reopen Poll' => 'Vuelva a abrir la encuesta',
  'Reset my vote' => 'Reiniciar mi voto',
  'Vote' => 'Votar',
  'and {count} more vote for this.' => 'y {count} mas votaron por esto.',
  'votes' => 'votos',
);
