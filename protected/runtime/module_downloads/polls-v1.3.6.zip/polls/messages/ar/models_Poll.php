<?php
return array (
  'Answers' => 'الإجابات',
  'Description' => 'الوصف',
  'Multiple answers per user' => 'إجابات متعددة لكل مستخدم',
  'Please specify at least {min} answers!' => 'يرجى تحديد {min} من الإجابات على الأقل!',
  'Poll' => 'استطلاع',
  'Question' => 'سؤال',
);
