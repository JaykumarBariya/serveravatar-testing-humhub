<?php
return array (
  '{userName} answered the {question}.' => 'أجاب {userName} على {question}.',
);
