<?php
return array (
  'Access denied!' => 'تم منع الوصول!',
  'Anonymous poll!' => 'استطلاع كمجهول!',
  'Could not load poll!' => 'فشل تحميل الاستطلاع!',
  'Invalid answer!' => 'إجابة غير صالحة!',
  'Users voted for: <strong>{answer}</strong>' => 'صوّت المستخدمون لـ: <strong>{answer}</strong>',
  'Voting for multiple answers is disabled!' => 'تم تعطيل التصويت لإجابات متعددة!',
  'You have insufficient permissions to perform that operation!' => 'ليس لديك الأذونات الكافية لتنفيذ هذه العملية!',
);
