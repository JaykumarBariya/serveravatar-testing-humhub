<?php
return array (
  'Allows the user to create polls' => 'السماح للمستخدم بإنشاء استطلاعات الرأي',
  'Allows to start polls.' => 'السماح ببدء الاستطلاعات.',
  'Answers' => 'الإجابات',
  'At least one answer is required' => 'مطلوب إجابة واحدة على الأقل',
  'Cancel' => 'إلغاء',
  'Create poll' => 'إنشاء استطلاع',
  'Polls' => 'الاستطلاعات',
  'Save' => 'حفظ',
  '{n,plural,=1{# {htmlTagBegin}vote{htmlTagEnd}}other{# {htmlTagBegin}votes{htmlTagEnd}}}' => '{n,plural,=1{# {htmlTagBegin}صوت{htmlTagEnd}}other{# {htmlTagBegin}أصوات{htmlTagEnd}}}',
);
