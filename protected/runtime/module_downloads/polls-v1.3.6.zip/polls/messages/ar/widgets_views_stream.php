<?php
return array (
  '<b>There are no polls yet!</b>' => '<b>لا توجد استطلاعات رأي حتى الآن!</b>',
  '<b>There are no polls yet!</b><br>Be the first and create one...' => '<b>لا توجد استطلاعات رأي حتى الآن!</b><br>كن الأول وأنشئ واحداً...',
  'Asked by me' => 'طرح من قبلي',
  'No answered yet' => 'لم تتم الإجابة بعد',
  'Only private polls' => 'استطلاعات الرأي الخاصة فقط',
  'Only public polls' => 'استطلاعات الرأي العامة فقط',
);
