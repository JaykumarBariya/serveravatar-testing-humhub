<?php
return array (
  '<strong>Note:</strong> The result is hidden until the poll is closed by a moderator.' => '<strong>ملاحظة:</strong> يتم إخفاء النتيجة حتى يتم إغلاق الاستطلاع بواسطة المشرف.',
  'Anonymous' => 'مجهول',
  'Closed' => 'مغلق',
  'Complete Poll' => 'إكمال الاستطلاع',
  'Reopen Poll' => 'إعادة فتح الاستطلاع',
  'Reset my vote' => 'إعادة تعيين تصويتي',
  'Vote' => 'التصويت',
  'and {count} more vote for this.' => 'و{count} المزيد من الأصوات لهذا.',
  'votes' => 'أصوات',
);
