<?php
return array (
  '{userName} created a new poll and assigned you.' => 'أنشأ {userName} استطلاعًا جديدًا وقام بتعيينه لك.',
);
