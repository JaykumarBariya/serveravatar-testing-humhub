<?php
return array (
  'Add answer...' => 'إضافة إجابة',
  'Anonymous Votes?' => 'أصوات مجهولة؟',
  'Description' => 'الوصف',
  'Display answers in random order?' => 'عرض الإجابات بترتيب عشوائي؟',
  'Edit answer (empty answers will be removed)...' => 'تحرير الإجابة (الإجابة الفارغة سيتم حذفها)...',
  'Edit your poll question...' => 'تحرير سؤال استطلاعك',
  'Hide results until poll is closed?' => 'إخفاء النتائج حتى يغلق التصويت؟',
  'Question' => 'السؤال',
);
