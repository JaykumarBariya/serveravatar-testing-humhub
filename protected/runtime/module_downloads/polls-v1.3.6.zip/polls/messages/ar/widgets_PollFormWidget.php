<?php
return array (
  'Ask' => 'اسأل',
);
