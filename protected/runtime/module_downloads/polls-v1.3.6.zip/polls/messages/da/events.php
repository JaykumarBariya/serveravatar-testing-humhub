<?php

return [
    'Again? ;Weary;' => 'Igen? ;Weary;',
    'Club A Steakhouse' => '',
    'Location of the next meeting' => '',
    'Pisillo Italian Panini' => '',
    'Right now, we are in the planning stages for our next meetup and we would like to know from you, where you would like to go?' => '',
    'To Daniel' => '',
    'Why don\'t we go to Bemelmans Bar?' => '',
];
