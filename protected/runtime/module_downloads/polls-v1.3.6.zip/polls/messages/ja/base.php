<?php
return array (
  'Allows the user to create polls' => '投票を作成できるようにします',
  'Allows to start polls.' => '投票形式のアンケートを開始できます。',
  'Answers' => '回答',
  'At least one answer is required' => '1つ以上の回答が必要です',
  'Cancel' => 'キャンセル',
  'Create poll' => '投票を作成する',
  'Polls' => 'アンケート',
  'Save' => '保存',
  '{n,plural,=1{# {htmlTagBegin}vote{htmlTagEnd}}other{# {htmlTagBegin}votes{htmlTagEnd}}}' => '{n,plural,=1{# {htmlTagBegin}vote{htmlTagEnd}}other{# {htmlTagBegin}votes{htmlTagEnd}}}',
);
