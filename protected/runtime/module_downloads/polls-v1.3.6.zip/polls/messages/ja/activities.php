<?php
return array (
  'Polls' => 'アンケート',
  'Whenever someone participates in a poll.' => '誰かが投票に参加するときはいつでも。',
);
