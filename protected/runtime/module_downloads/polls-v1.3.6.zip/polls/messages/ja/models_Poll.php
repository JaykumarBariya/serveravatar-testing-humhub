<?php
return array (
  'Answers' => '回答',
  'Description' => '説明',
  'Multiple answers per user' => 'ユーザーごとの複数回答',
  'Please specify at least {min} answers!' => '少なくとも {min} の回答を指定してください！',
  'Poll' => 'アンケート',
  'Question' => '質問',
);
