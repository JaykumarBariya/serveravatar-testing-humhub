<?php
return array (
  'Answers' => 'Erantzunak',
  'Description' => 'Deskribapena',
  'Multiple answers per user' => 'Hainbat erantzun erabiltzaile bakoitzeko',
  'Please specify at least {min} answers!' => 'Mesedez, zehaztu zerrendan gutxienez {min} erantzun!',
  'Poll' => 'Inkesta',
  'Question' => 'Galdera',
);
