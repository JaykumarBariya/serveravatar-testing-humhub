<?php
return array (
  'Again? ;Weary;' => 'Berriro? ;Nekatuta;',
  'Club A Steakhouse' => 'Club A erretegia',
  'Location of the next meeting' => 'Hurrengo bileraren kokapena',
  'Pisillo Italian Panini' => 'Pisillo italiar paninia',
  'Right now, we are in the planning stages for our next meetup and we would like to know from you, where you would like to go?' => 'Oraintxe bertan, gure hurrengo topaketaren urratsak planifikatzen ari gara eta nora joan nahi duzun jakin nahiko genuke.',
  'To Daniel' => 'Danielentzat',
  'Why don\'t we go to Bemelmans Bar?' => 'Zergatik ez gara Bemelmans tabernara joaten?',
);
