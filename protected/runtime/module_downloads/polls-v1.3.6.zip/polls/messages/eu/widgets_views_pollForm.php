<?php
return array (
  'Add answer...' => 'Gehitu erantzuna...',
  'Anonymous Votes?' => 'Bozka anonimoak?',
  'Description' => 'Deskribapena',
  'Display answers in random order?' => 'Erantzunak ausazko ordenean erakutsi nahi dituzu?',
  'Edit answer (empty answers will be removed)...' => 'Editatu erantzuna (hutsik dauden erantzunak kenduko dira)...',
  'Edit your poll question...' => 'Editatu zure inkestako galdera...',
  'Hide results until poll is closed?' => 'Inkesta itxi arte emaitzak ezkutatu ?',
  'Question' => 'Galdera',
);
