<?php
return array (
  'Polls' => 'Inkestak',
  'Whenever someone participates in a poll.' => 'Norbaitek inkesta batean parte hartzen duen aldiro.',
);
