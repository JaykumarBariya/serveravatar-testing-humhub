<?php
return array (
  'Add answer...' => 'Dodaj odpowiedź...',
  'Anonymous Votes?' => 'Głosy anonimowe?',
  'Description' => 'Opis',
  'Display answers in random order?' => 'Wyświetlaj odpowiedzi w losowej kolejności?',
  'Edit answer (empty answers will be removed)...' => 'Edytuj odpowiedź (puste odpowiedzi zostaną usunięte)...',
  'Edit your poll question...' => 'Edytuj pytanie głosowania...',
  'Hide results until poll is closed?' => 'Ukryć wyniki do momentu aż ankieta nie zostanie zamknięta?',
  'Question' => 'Pytanie ',
);
