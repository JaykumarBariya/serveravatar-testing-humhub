<?php
return array (
  'Polls' => 'Głosowania',
  'Whenever someone participates in a poll.' => 'Za każdym razem gdy ktoś wypełni głosowanie.',
);
