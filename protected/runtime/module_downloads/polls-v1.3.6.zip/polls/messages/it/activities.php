<?php
return array (
  'Polls' => 'Sondaggi',
  'Whenever someone participates in a poll.' => 'Ogni volta che qualcuno partecipa a un sondaggio.',
);
