<?php
return array (
  'Allows the user to create polls' => 'Позволяет пользователю создавать опросы',
  'Allows to start polls.' => 'Разрешить создавать опросы',
  'Answers' => 'Ответы',
  'At least one answer is required' => 'Требуется хотя бы один ответ',
  'Cancel' => 'Отменить',
  'Create poll' => 'Создать опрос',
  'Polls' => 'Опросы',
  'Save' => 'Сохранить',
  '{n,plural,=1{# {htmlTagBegin}vote{htmlTagEnd}}other{# {htmlTagBegin}votes{htmlTagEnd}}}' => '',
);
