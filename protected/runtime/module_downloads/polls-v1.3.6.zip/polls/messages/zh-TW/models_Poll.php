<?php
return array (
  'Answers' => '',
  'Description' => '描述',
  'Multiple answers per user' => '',
  'Please specify at least {min} answers!' => '',
  'Poll' => '',
  'Question' => '',
);
