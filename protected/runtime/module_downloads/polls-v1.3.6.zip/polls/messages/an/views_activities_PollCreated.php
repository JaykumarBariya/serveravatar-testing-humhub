<?php
return array (
  '{userName} created a new {question}.' => '{userName} ha creyau la pregunta {question}.',
);
