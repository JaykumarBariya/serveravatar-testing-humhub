<?php
return array (
  'Polls' => 'Enqüestas',
  'Whenever someone participates in a poll.' => '',
);
