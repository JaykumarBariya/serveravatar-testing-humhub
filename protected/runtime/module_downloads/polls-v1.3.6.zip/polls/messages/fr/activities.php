<?php
return array (
  'Polls' => 'Sondages',
  'Whenever someone participates in a poll.' => 'Lorsque quelqu’un participe à un sondage.',
);
