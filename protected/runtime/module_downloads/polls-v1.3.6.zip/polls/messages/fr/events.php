<?php
return array (
  'Again? ;Weary;' => 'Encore ? ;Weary;',
  'Club A Steakhouse' => 'Hippopotamus',
  'Location of the next meeting' => 'Lieu du prochain rendez-vous',
  'Pisillo Italian Panini' => 'Panini chez Pisillo',
  'Right now, we are in the planning stages for our next meetup and we would like to know from you, where you would like to go?' => 'Nous sommes en train de préparer notre prochaine rencontre, et nous voudrions savoir où vous aimeriez aller ?',
  'To Daniel' => 'Chez Daniel',
  'Why don\'t we go to Bemelmans Bar?' => 'Pourquoi on n\'irait pas au bar Bemelmans ?',
);
