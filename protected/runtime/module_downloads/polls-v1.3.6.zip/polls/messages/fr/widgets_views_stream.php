<?php
return array (
  '<b>There are no polls yet!</b>' => '<b>Il n\'y a aucun sondage actuellement.</b>',
  '<b>There are no polls yet!</b><br>Be the first and create one...' => '<b>Il n\'y a aucun sondage actuellement.</b><br>Soyez le premier à en créer un...',
  'Asked by me' => 'Mes demandes',
  'No answered yet' => 'Pas de votes',
  'Only private polls' => 'Sondages privés seulement',
  'Only public polls' => 'Sondages public seulement',
);
