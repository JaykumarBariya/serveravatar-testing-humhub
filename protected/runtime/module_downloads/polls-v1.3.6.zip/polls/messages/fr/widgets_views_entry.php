<?php
return array (
  '<strong>Note:</strong> The result is hidden until the poll is closed by a moderator.' => '<strong>Note :</strong> Les résultats sont cachés jusqu\'à ce que le sondage soit fermé par le modérateur.',
  'Anonymous' => 'Anonyme',
  'Closed' => 'Fermé',
  'Complete Poll' => 'Fermer le sondage',
  'Reopen Poll' => 'Ré-ouvrir le sondage',
  'Reset my vote' => 'Annuler mon vote',
  'Vote' => 'Voter',
  'and {count} more vote for this.' => 'et {count} votes en plus.',
  'votes' => 'vote(s)',
);
