<?php
return array (
  '{userName} created a new poll and assigned you.' => '{userName} a créé un nouveau sondage et vous l\'a affecté.',
);
