<?php
return array (
  '<strong>Note:</strong> The result is hidden until the poll is closed by a moderator.' => '<strong>Забележка:</strong> Резултатът е скрит, докато анкетата не бъде затворена от модератор.',
  'Anonymous' => 'Анонимен',
  'Closed' => 'Затворена',
  'Complete Poll' => 'Завърши анкета',
  'Reopen Poll' => 'Отвори отново анкета',
  'Reset my vote' => 'Нулирай гласа ми',
  'Vote' => 'Гласувай',
  'and {count} more vote for this.' => 'и {count} гласа за това.',
  'votes' => 'гласове',
);
