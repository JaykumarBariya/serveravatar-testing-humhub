<?php
return array (
  '{userName} answered the {question}.' => '{userName} ענה על {question}.',
);
