<?php
return array (
  'Access denied!' => 'Prístup zamietnutý!',
  'Anonymous poll!' => 'Anonymná anketa!',
  'Could not load poll!' => 'Anketu sa nepodarilo načítať!',
  'Invalid answer!' => 'Neplatná odpoveď!',
  'Users voted for: <strong>{answer}</strong>' => 'Používatelia hlasovali za: <strong>{answer}</strong>',
  'Voting for multiple answers is disabled!' => 'Hlasovanie za viacero odpovedí je zakázané!',
  'You have insufficient permissions to perform that operation!' => 'Nemáte dostatočné povolenia na vykonanie tejto operácie!',
);
