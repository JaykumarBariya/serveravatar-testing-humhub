<?php
return array (
  'Add answer...' => 'Pridať odpoveď...',
  'Anonymous Votes?' => 'Anonymné hlasy?',
  'Description' => 'Popis',
  'Display answers in random order?' => 'Zobraziť odpovede v náhodnom poradí?',
  'Edit answer (empty answers will be removed)...' => 'Upraviť odpoveď (prázdne odpovede budú odstránené)...',
  'Edit your poll question...' => 'Upravte svoju anketovú otázku...',
  'Hide results until poll is closed?' => 'Skryť výsledky, kým sa anketa neuzavrie?',
  'Question' => 'Otázka',
);
