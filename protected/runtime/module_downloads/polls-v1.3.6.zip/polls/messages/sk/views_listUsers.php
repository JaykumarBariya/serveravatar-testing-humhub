<?php
return array (
  'User who vote this' => 'Používateľ, ktorý hlasuje za toto',
);
