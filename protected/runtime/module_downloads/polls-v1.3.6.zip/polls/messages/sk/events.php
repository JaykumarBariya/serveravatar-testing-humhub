<?php
return array (
  'Again? ;Weary;' => 'Opäť? ;Weary;',
  'Club A Steakhouse' => 'Klub A Steakhouse',
  'Location of the next meeting' => 'Miesto nasledujúceho stretnutia',
  'Pisillo Italian Panini' => 'Pisillo Italian Panini',
  'Right now, we are in the planning stages for our next meetup and we would like to know from you, where you would like to go?' => 'Práve teraz sme vo fáze plánovania nášho ďalšieho stretnutia a chceli by sme od vás vedieť, kam by ste chceli ísť?',
  'To Daniel' => 'Danielovi',
  'Why don\'t we go to Bemelmans Bar?' => 'Prečo nejdeme do baru Bemelmans?',
);
