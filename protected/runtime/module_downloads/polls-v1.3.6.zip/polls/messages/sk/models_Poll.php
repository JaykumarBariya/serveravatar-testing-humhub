<?php
return array (
  'Answers' => 'Odpovede',
  'Description' => 'Popis',
  'Multiple answers per user' => 'Viaceré odpovede na jedného používateľa',
  'Please specify at least {min} answers!' => 'Zadajte aspoň {min} odpovedí!',
  'Poll' => 'Anketa',
  'Question' => 'Otázka',
);
