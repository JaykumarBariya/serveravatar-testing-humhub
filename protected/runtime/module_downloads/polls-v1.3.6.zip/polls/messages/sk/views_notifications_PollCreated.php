<?php
return array (
  '{userName} created a new poll and assigned you.' => '{userName} vytvoril nový prieskum a priradil  Vás.',
);
