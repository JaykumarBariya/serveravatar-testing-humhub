<?php
return array (
  '<b>There are no polls yet!</b>' => '<b>Zatiaľ neexistujú žiadne prieskumy!</b>',
  '<b>There are no polls yet!</b><br>Be the first and create one...' => '<b>Zatiaľ neexistujú žiadne ankety!</b><br>Buďte prvý a vytvorte ju...',
  'Asked by me' => 'Pýtam sa',
  'No answered yet' => 'Zatiaľ žiadna odpoveď',
  'Only private polls' => 'Iba súkromné ​​prieskumy',
  'Only public polls' => 'Iba verejné prieskumy',
);
