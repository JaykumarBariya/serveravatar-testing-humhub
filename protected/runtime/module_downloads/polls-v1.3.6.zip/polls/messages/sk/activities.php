<?php
return array (
  'Polls' => 'Ankety',
  'Whenever someone participates in a poll.' => 'Vždy, keď sa niekto zúčastní ankety.',
);
