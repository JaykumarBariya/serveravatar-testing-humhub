<?php
/**
 * Here you can overwrite your API humhub config. The default config resiedes in @humhubTests/codeception/config/config.php
 */
return [];
