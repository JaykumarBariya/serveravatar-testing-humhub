<?php
/**
 * Initialize the HumHub Application for API testing. The default application configuration for this suite can be overwritten
 * in @tests/config/api.php
 */
require(Yii::getAlias('@humhubTests/codeception/acceptance/_bootstrap.php'));
